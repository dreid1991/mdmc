#ifndef DATA_BLOCK_H
#define DATA_BLOCK_H
class BlockAvgs {
	public:
		double temp;
		double press;
		double dens;
		double engKinetic;
		double engPotential;
		double engTotal;

};


#endif
