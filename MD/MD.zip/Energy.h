#ifndef ENERGY_H
#define ENERGY_H
class Energy {
	public:
		Energy() : potential(0), kinetic(0) {};
		double potential;
		double kinetic;
};
#endif
