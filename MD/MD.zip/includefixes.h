#ifndef INCLUDE_FIXES_H
#define INCLUDE_FIXES_H
#include "FixLjCut.h" //file to include all of the fixes.  Don't want to write them all.  will slow down compilation if used when not necessary
#include "FixNVT.h"
#endif

